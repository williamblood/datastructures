/*
    (name header)
*/

#include "BST.h"

using namespace std;

// Definition function insert (non-recursive) 


// Definition function totalNodes


// Definition function totalNodes (recursive)


// Definition overloaded function preorderTraversal


// Definition overloaded function preorderTraversal (recursive)


// Definition overloaded function postorderTraversal


// Definition overloaded function postorderTraversal (recursive)
